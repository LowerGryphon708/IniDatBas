
import pandas as pd
import requests

IP_Orion="192.168.1.77"
Port_Orion="1026"

# Crea entidad juego
def crear_juego(Id,Titulo,Portable,MaxJugador,Multiplatforma,Online,Genero,Desarrollador,Console,Rating,Year):
            '''Sirve para crear un juego'''
            try:
                ContextDataJSON={"id": Id,
                                "type": "juego",

                                "Titulo": {
                                "value": Titulo,
                                "type": "String"
                                },
                                "Portable": {
                                "value": Portable,
                                "type": "String"
                                },
                                "MaxJugador": {
                                "value": MaxJugador,
                                "type": "String"
                                },
                                "Multiplatforma": {
                                "value": Multiplatforma,
                                "type": "String"
                                },
                                "Online": {
                                "value": Online,
                                "type": "String"
                                },
                                "Genero": {
                                "value": Genero,
                                "type": "String"
                                },
                                "Desarrollador": {
                                "value": Desarrollador,
                                "type": "String"
                                },
                                "Console": {
                                "value": Console,
                                "type": "String"
                                },
                                "Rating": {
                                "value": Rating,
                                "type": "String"
                                },
                                "Year": {
                                "value": Year,
                                "type": "String"
                                }                    
                                }
                
                # ContextDataJSON['id']='abono_'+str(servicio)  # Nombre de la entidad abono abono_servicio_+randit()
                url='http://'+IP_Orion+':'+Port_Orion+'/v2/entities'
                # print(url)
                headers={"Accept":"application/json"}
                response= requests.post(url,headers=headers,json=ContextDataJSON) 
                # print(response.status_code)
                if (response.status_code) == 201:
                    print('Entidad creada satisfactoriamente')
                    return 
                else:
                    # print('La entidad ya existe')
                    print(response.content)
                    return
            except:
                 print('ORION-Server offline')

###############################
# Actualiza base de datos
###############################
def actualiza_base(file):
    datos_csv = pd.read_csv(file,delimiter=';', encoding='latin-1')
    datos_csv = datos_csv.reset_index()
    for index, row in datos_csv.iterrows():
            # if index==1211:
                Id=str(row['ID'])
                Titulo=row['Titulo'].replace(':', ' ')
                Portable=row['Portable']
                MaxJugador=str(row['Max Jugadores'])
                Multiplatforma=row['Multiplatforma']
                Online=row['Online']
                Genero=row['Genero'].replace(')', ' ').replace('(', ' ').replace('/', ' ')
                Desarrollador=row['Desarrollador']
                Desarrollador=row['Desarrollador'] if isinstance (row['Desarrollador'], str)  else ' '
                Console=row['Console']
                Rating=str(row['Rating'])
                Year=str(row['Year'])

                crear_juego(Id,Titulo,Portable,MaxJugador,Multiplatforma,Online,Genero,Desarrollador,Console,Rating,Year)
            


actualiza_base('video_games.csv')